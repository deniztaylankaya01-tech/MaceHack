package com.example.macehack;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.mob.HostileEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.registry.tag.ItemTags;
import net.minecraft.screen.slot.SlotActionType;
import net.minecraft.text.Text;
import net.minecraft.util.Hand;
import net.minecraft.util.math.Vec3d;
import org.lwjgl.glfw.GLFW;

/**
 * Auto Mace (client-side Fabric mod, 1.21.11, Yarn mappings).
 *
 * Press R to toggle. Loop:
 *   on ground + target nearby -> wear elytra -> jump + glide -> fireworks upward
 *   -> at height, swap to chestplate (stops gliding) + select mace
 *   -> fall onto target and smash -> cooldown -> repeat.
 *
 * Needs in your inventory: elytra, a chestplate, a mace (hotbar), fireworks (hotbar).
 */
public class MaceHackClient implements ClientModInitializer {

    // ---------------- settings ----------------
    private static final double  TARGET_RANGE   = 40.0;  // blocks
    private static final double  ASCEND_HEIGHT  = 30.0;  // blocks to climb before diving
    private static final double  REACH          = 3.2;   // attack distance
    private static final int     ROCKET_EVERY   = 14;    // ticks between firework uses
    private static final boolean TARGET_PLAYERS = false; // true = also target other players

    private enum State { IDLE, PREP, JUMP, ASCEND, DIVE, RECOVER, COOLDOWN }

    private KeyBinding toggleKey;
    private boolean enabled = false;
    private State state = State.IDLE;
    private int timer = 0;
    private double startY = 0;
    private LivingEntity target = null;

    @Override
    public void onInitializeClient() {
        toggleKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.macehack.toggle",
                InputUtil.Type.KEYSYM,
                GLFW.GLFW_KEY_R,
                KeyBinding.Category.MISC));
        ClientTickEvents.END_CLIENT_TICK.register(this::tick);
    }

    // ---------------- main loop ----------------
    private void tick(MinecraftClient mc) {
        ClientPlayerEntity p = mc.player;
        if (p == null || mc.world == null || mc.interactionManager == null) {
            resetAll(mc);
            return;
        }

        while (toggleKey.wasPressed()) {
            enabled = !enabled;
            resetAll(mc);
            p.sendMessage(Text.literal("Auto Mace: " + (enabled ? "ON" : "OFF")), true);
        }
        if (!enabled || mc.currentScreen != null) return;

        timer++;

        switch (state) {
            case IDLE -> {
                if (!p.isOnGround() || p.isGliding()) return;
                target = findTarget(mc, p);
                if (target == null) return;
                String missing = missingGear(p);
                if (missing != null) {
                    enabled = false;
                    p.sendMessage(Text.literal("Auto Mace off: " + missing), true);
                    return;
                }
                state = State.PREP;
                timer = 0;
            }

            case PREP -> {
                equipChest(mc, p, true);
                selectItem(p, Items.FIREWORK_ROCKET);
                state = State.JUMP;
                timer = 0;
            }

            case JUMP -> {
                if (p.isGliding()) {
                    setJump(mc, false);
                    startY = p.getY();
                    state = State.ASCEND;
                    timer = 0;
                    return;
                }
                if (timer == 2) setJump(mc, true);        // jump off the ground
                else if (timer == 4) setJump(mc, false);  // release
                else if (timer == 8) setJump(mc, true);   // press again in the air -> start gliding
                else if (timer > 40) toCooldown(mc);      // failed to glide
            }

            case ASCEND -> {
                if (target == null || !target.isAlive()) { toCooldown(mc); return; }
                double gained = p.getY() - startY;
                if (!p.isGliding()) {
                    if (gained > 8) beginDive(mc, p); else toCooldown(mc);
                    return;
                }
                selectItem(p, Items.FIREWORK_ROCKET);
                aim(p, target, true);
                if (timer % ROCKET_EVERY == 1 && hotbarSlotOf(p, Items.FIREWORK_ROCKET) >= 0) {
                    mc.interactionManager.interactItem(p, Hand.MAIN_HAND);
                }
                double ceiling = mc.world.getBottomY() + mc.world.getHeight() - 8;
                boolean outOfRockets = hotbarSlotOf(p, Items.FIREWORK_ROCKET) < 0 && gained > 6;
                if (gained >= ASCEND_HEIGHT || p.getY() >= ceiling || outOfRockets || timer > 400) {
                    beginDive(mc, p);
                }
            }

            case DIVE -> {
                if (target == null || !target.isAlive()) { recover(mc, p); return; }
                if (p.getEquippedStack(EquipmentSlot.CHEST).isOf(Items.ELYTRA) && timer < 10) {
                    equipChest(mc, p, false); // retry swap if it did not go through
                }
                selectItem(p, Items.MACE);
                aim(p, target, false);

                double horiz = horizontalDist(p, target);
                setForward(mc, horiz > 1.2);

                if (p.fallDistance > 1.5 && p.distanceTo(target) <= REACH) {
                    mc.interactionManager.attackEntity(p, target);
                    p.swingHand(Hand.MAIN_HAND);
                    toCooldown(mc);
                } else if (p.isOnGround() && timer > 5) {
                    toCooldown(mc);
                } else if (horiz > 14 && timer > 6) {
                    recover(mc, p); // drifting off target: glide away instead of eating fall damage
                }
            }

            case RECOVER -> {
                p.setPitch(10f);
                if (p.isGliding() || p.isOnGround() || timer > 60) {
                    toCooldown(mc);
                    return;
                }
                setJump(mc, timer % 4 == 3); // tap jump repeatedly until gliding starts
            }

            case COOLDOWN -> {
                if (timer >= 40 && p.isOnGround()) {
                    state = State.IDLE;
                    timer = 0;
                }
            }
        }
    }

    // ---------------- state helpers ----------------
    private void beginDive(MinecraftClient mc, ClientPlayerEntity p) {
        equipChest(mc, p, false);   // chestplate on = elytra off = stop gliding, start falling
        selectItem(p, Items.MACE);
        setJump(mc, false);
        state = State.DIVE;
        timer = 0;
    }

    private void recover(MinecraftClient mc, ClientPlayerEntity p) {
        equipChest(mc, p, true);
        setForward(mc, false);
        state = State.RECOVER;
        timer = 0;
    }

    private void toCooldown(MinecraftClient mc) {
        setJump(mc, false);
        setForward(mc, false);
        state = State.COOLDOWN;
        timer = 0;
    }

    private void resetAll(MinecraftClient mc) {
        state = State.IDLE;
        timer = 0;
        target = null;
        if (mc.options != null) {
            setJump(mc, false);
            setForward(mc, false);
        }
    }

    private void setJump(MinecraftClient mc, boolean v)    { mc.options.jumpKey.setPressed(v); }
    private void setForward(MinecraftClient mc, boolean v) { mc.options.forwardKey.setPressed(v); }

    // ---------------- targeting / aiming ----------------
    private LivingEntity findTarget(MinecraftClient mc, ClientPlayerEntity p) {
        LivingEntity best = null;
        double bestSq = TARGET_RANGE * TARGET_RANGE;
        for (Entity e : mc.world.getEntities()) {
            if (e == p || !(e instanceof LivingEntity le) || !le.isAlive()) continue;
            boolean ok = e instanceof HostileEntity || (TARGET_PLAYERS && e instanceof PlayerEntity);
            if (!ok) continue;
            double d = p.squaredDistanceTo(e);
            if (d < bestSq) { bestSq = d; best = le; }
        }
        return best;
    }

    private double horizontalDist(ClientPlayerEntity p, Entity t) {
        double dx = t.getX() - p.getX();
        double dz = t.getZ() - p.getZ();
        return Math.sqrt(dx * dx + dz * dz);
    }

    /** Face the target. If pitchUp, look steeply upward (for climbing) instead of at the target. */
    private void aim(ClientPlayerEntity p, LivingEntity t, boolean pitchUp) {
        Vec3d from = p.getEyePos();
        double dx = t.getX() - from.x;
        double dy = t.getBodyY(0.5) - from.y;
        double dz = t.getZ() - from.z;
        double h = Math.sqrt(dx * dx + dz * dz);
        p.setYaw((float) (Math.toDegrees(Math.atan2(dz, dx)) - 90.0));
        p.setPitch(pitchUp ? -55f : (float) (-Math.toDegrees(Math.atan2(dy, h))));
    }

    // ---------------- inventory helpers ----------------
    private String missingGear(ClientPlayerEntity p) {
        if (hotbarSlotOf(p, Items.MACE) < 0) return "put a mace in your hotbar";
        if (hotbarSlotOf(p, Items.FIREWORK_ROCKET) < 0) return "put fireworks in your hotbar";
        if (!hasChest(p, true)) return "no elytra found";
        if (!hasChest(p, false)) return "no chestplate found";
        return null;
    }

    private boolean matches(ItemStack s, boolean elytra) {
        if (elytra) return s.isOf(Items.ELYTRA);
        return !s.isOf(Items.ELYTRA) && s.isIn(ItemTags.CHEST_ARMOR);
    }

    private boolean hasChest(ClientPlayerEntity p, boolean elytra) {
        if (matches(p.getEquippedStack(EquipmentSlot.CHEST), elytra)) return true;
        for (int i = 0; i < 36; i++) {
            if (matches(p.getInventory().getStack(i), elytra)) return true;
        }
        return false;
    }

    private int hotbarSlotOf(ClientPlayerEntity p, Item item) {
        for (int i = 0; i < 9; i++) {
            if (p.getInventory().getStack(i).isOf(item)) return i;
        }
        return -1;
    }

    private void selectItem(ClientPlayerEntity p, Item item) {
        int s = hotbarSlotOf(p, item);
        if (s >= 0 && p.getInventory().getSelectedSlot() != s) {
            p.getInventory().setSelectedSlot(s);
        }
    }

    /** Swap the chest slot to elytra (true) or a chestplate (false) using inventory clicks. */
    private void equipChest(MinecraftClient mc, ClientPlayerEntity p, boolean wantElytra) {
        if (matches(p.getEquippedStack(EquipmentSlot.CHEST), wantElytra)) return;
        for (int i = 0; i < 36; i++) {
            if (!matches(p.getInventory().getStack(i), wantElytra)) continue;
            int slot = i < 9 ? i + 36 : i;      // hotbar = 36..44, main = 9..35
            int id = p.playerScreenHandler.syncId;
            mc.interactionManager.clickSlot(id, slot, 0, SlotActionType.PICKUP, p); // pick up new piece
            mc.interactionManager.clickSlot(id, 6, 0, SlotActionType.PICKUP, p);    // chest armor slot = 6
            mc.interactionManager.clickSlot(id, slot, 0, SlotActionType.PICKUP, p); // put old piece back
            return;
        }
    }
}
